
package services;


public interface CSVSerializable {

    
    String toCSV();
}
