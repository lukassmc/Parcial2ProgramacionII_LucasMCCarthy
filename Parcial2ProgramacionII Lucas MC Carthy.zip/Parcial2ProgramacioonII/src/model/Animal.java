
package model;

import services.CSVSerializable;


public class Animal implements Comparable<Animal>, CSVSerializable {

    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;
    
    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

     public String getNombre() {
        return nombre;
    }


    public String getEspecie() {
        return especie;
    }


    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public void setAlimentacion(TipoAlimentacion alimentacion) {
        this.alimentacion = alimentacion;
    }

    public int getId() {
        return id;
    }
    
   @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }
  


   @Override
    public int compareTo(Animal other) {
        return Integer.compare(this.id, other.id);
    }
    
    
}
