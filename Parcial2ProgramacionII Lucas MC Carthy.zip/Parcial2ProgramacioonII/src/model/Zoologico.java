
package model;

import services.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class Zoologico<T extends CSVSerializable & Comparable <T>> {
    private List<T> inventarioZoo = new ArrayList<>();
    
    
 



    
      public void agregar(T objeto) {
        inventarioZoo.add(objeto);
    }
      
      
    public T obtener(int indice) {
        return inventarioZoo.get(indice);
    }

    public void eliminar(int indice) {
        inventarioZoo.remove(indice);
    }
    
    public void paraCadaElemento(Consumer<T> accion) {
    for (T objeto : inventarioZoo) {
        accion.accept(objeto);
    }
}
    
    public List<T> filtrar(Predicate<T> criterio){
        List<T> auxList = new ArrayList<>();
        
        for (T objeto : inventarioZoo){
            if (criterio.test(objeto)){
                auxList.add(objeto);
            }
        
        }
        return auxList;
    }
    
    
     public void ordenar() {
        Collections.sort(inventarioZoo);
    }
     
     public void ordenarPorEspecie(Comparator<T> comparator) {
        inventarioZoo.sort(comparator);
    }
     
     
     
  public List<T> filtrarPorTipoAlimentacion(TipoAlimentacion tipo) {
    List<T> toReturn= new ArrayList<>();
    for (T objeto : inventarioZoo) {
        if (objeto instanceof Animal) {
            Animal animal = (Animal) objeto;
            if (animal.getAlimentacion() == tipo) {
                toReturn.add(objeto);
            }
        }
    }
    return toReturn;
}

public void guardarArchivo(String path) throws IOException {
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
        oos.writeObject(inventarioZoo);
    }
}  

public void cargarArchivo(String path) throws IOException, ClassNotFoundException {
    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
        inventarioZoo = (List<T>) ois.readObject();
    }
}
    
public void guardarBinario(List<T> lista, String path) {
    
        try (FileOutputStream file = new FileOutputStream(path);
             ObjectOutputStream out = new ObjectOutputStream(file)) {
            out.writeObject(lista);
        } catch (IOException ex) {
            System.out.println("Error al guardar el archivo binario: " + ex.getMessage());
        }
    }
     
     
    public void guardarCSV( String path){
        if (inventarioZoo == null || inventarioZoo.isEmpty()) {
        System.out.println("La lista está vacía, no se puede guardar.");
        return;
    }
        
        File file = new File(path);

        try{
            if(file.exists()){
                System.out.println("Error, este archivo ya existe.");
            }else{
                file.createNewFile();
            }
        } catch (IOException ex){
            System.out.println("Hubo un error al crear el archivo.");
        }

        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("ID,Nombre,Especie,Alimentacion\n");
            for(CSVSerializable obj : inventarioZoo){
                bw.write(obj.toCSV() + "\n");
            }
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
 

    
    
    public List<T> cargarCSV(String path){
        List<T> toReturn = new ArrayList<>();
        
        try(BufferedReader br = new BufferedReader(new FileReader(path))){
        String linea;
        
        br.readLine();
        
        while ((linea = br.readLine()) != null){
            String[] data = linea.split(",");
            
            if (data.length == 4){
            int id = Integer.parseInt(data[0]);
            String nombre = data[1];
            String especie= data [2];
            TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3]);
            
            
            Animal animal = new Animal(id, nombre, especie, alimentacion);
            toReturn.add((T) animal);
            } else {
                    System.out.println("Formato incorrecto en la línea: " + linea);
                }
        
        }
       
        } catch (IOException ex) {
            System.out.println("Error al leer el archivo CSV: " + ex.getMessage());
        }
        
        return toReturn;
    }
    
    
       public void agregarTodosCSV(String path) {
    List<T> animalesCargados = cargarCSV(path); 
    for (T animal : animalesCargados) {
        agregar(animal);
    }
}
            
    





}
     

    


 